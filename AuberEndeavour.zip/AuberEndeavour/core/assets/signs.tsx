<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="signs" tilewidth="128" tileheight="32" tilecount="6" columns="1">
 <image source="signs.png" width="128" height="192"/>
</tileset>
