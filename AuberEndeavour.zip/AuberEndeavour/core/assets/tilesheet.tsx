<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="tilesheet" tilewidth="16" tileheight="16" tilecount="272" columns="16">
 <image source="tilesheet.png" width="256" height="272"/>
</tileset>
