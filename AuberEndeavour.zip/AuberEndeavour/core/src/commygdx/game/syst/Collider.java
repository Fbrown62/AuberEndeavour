package commygdx.game.syst;

import com.badlogic.gdx.math.Vector2;

public class Collider {
    public Vector2 position;

    public Collider(Vector2 position){
        this.position = position;
    }
}
